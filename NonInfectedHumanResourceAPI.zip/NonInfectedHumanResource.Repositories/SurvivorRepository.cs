﻿using System;
using Dapper;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NonInfectedHumanResourceAPI.Repositories.Interfaces;
using NonInfectedHumanResourceAPI.Entities;
using System.Data.SqlClient;

using static System.Data.CommandType;

using System.Threading.Tasks;

namespace NonInfectedHumanResource.Repositories
{
    public class SurvivorRepository : BaseRepository, ISurvivorRepository
    {
        public bool AddSurvivor(Survivor survivor)
        {

       
            try
            {
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@SurvivorCode", survivor.SurvivorCode);
                parameters.Add("@Gender", survivor.Gender);
                parameters.Add("@Age", survivor.Age);
                parameters.Add("@Location", survivor.Location);
                parameters.Add("@IsInfected", survivor.IsInfected);
                parameters.Add("@ReportedCount", survivor.ReportedCount);
             

                SqlMapper.Execute(con, "AddSurvivor", param: parameters, commandType: StoredProcedure);
                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool DeleteSurvivor(int survivorId)
        {
            throw new NotImplementedException();
        }

     

        public IList<Survivor> GetAllSurvivor()
        {
            throw new NotImplementedException();
        }

       

        //public IList<Survivor> GetAllSurvivor()
        // {
        //   throw new NotImplementedException();
        //  }

        public IList<Survivor> GetAllUser() => SqlMapper.Query<Survivor>(con, "GetAllSurvivors", commandType: StoredProcedure).ToList();

        public IList<Survivor> GetPointLossFromInfectedSurvivor() => SqlMapper.Query<Survivor>(con, "GetPointLossFromInfectedSurvivor", commandType: StoredProcedure).ToList();


        public IList<Survivor> GetResourceAverage() => SqlMapper.Query<Survivor>(con, "GetResourceAverage", commandType: StoredProcedure).ToList();


        public IList<Survivor> GetAllUnInfectedSurvivor() => SqlMapper.Query<Survivor>(con, "GetAllUnInfectedSurvivor", commandType: StoredProcedure).ToList();


        public IList<Survivor> GetAllInfectedSurvivor() => SqlMapper.Query<Survivor>(con, "GetAllInfectedSurvivor", commandType: StoredProcedure).ToList();


    

        public Survivor GetSurvivorById(int survivorId)
        {
            try
            {
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@Id", survivorId);
                return SqlMapper.Query<Survivor>((SqlConnection)con, "GetUserById", parameters, commandType: StoredProcedure).FirstOrDefault();
            }
            catch (Exception)
            {

                throw;
            }
        }

        public bool UpdateSurvivor(Survivor survivor)
        {

            try
            {
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@Id", survivor.Id);
                parameters.Add("@SurvivorCode", survivor.SurvivorCode);
                parameters.Add("@Gender", survivor.Gender);
                parameters.Add("@Age", survivor.Age);
                parameters.Add("@Location", survivor.Location);
                parameters.Add("@IsInfected", survivor.IsInfected);
                parameters.Add("@ReportedCount", survivor.ReportedCount);

                SqlMapper.Execute(con, "UpdateUser", param: parameters, commandType: StoredProcedure);
                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }


}
