﻿using System;
using System.Collections.Generic;
using NonInfectedHumanResourceAPI.Entities;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NonInfectedHumanResourceAPI.Business.Interfaces
{
   

        public interface ISurvivorManager
        {
            bool AddSurvivor(Survivor survivor);

            bool UpdateSurvivor(Survivor survivor);

            bool DeleteSurvivor(int survivorId);

            IList<Survivor> GetAllSurvivor();

            Survivor GetSurvivorById(int survivorId);

           IList<Survivor> GetAllInfectedSurvivor();


           IList<Survivor> GetAllUnInfectedSurvivor();


            IList<Survivor> GetResourceAverage();

            IList<Survivor> GetPointLossFromInfectedSurvivor();


    }

}
