﻿using NonInfectedHumanResourceAPI.Business.Interfaces;
using NonInfectedHumanResourceAPI.Entities;
using NonInfectedHumanResourceAPI.Repositories.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NonInfectedHumanResourceAPI.Business
{
    public class SurvivorManager : ISurvivorManager
    {
        ISurvivorRepository _survivorRepository;
        public SurvivorManager(ISurvivorRepository survivorRepository)
        {
            _survivorRepository = survivorRepository;
        }
        public bool AddSurvivor(Survivor survivor)
        {
            return _survivorRepository.AddSurvivor(survivor);
        }

        public bool DeleteSurvivor(int survivorId)
        {
            return _survivorRepository.DeleteSurvivor(survivorId);
        }

        public IList<Survivor> GetAllInfectedSurvivor()
        {
            return _survivorRepository.GetAllInfectedSurvivor();
        }

        public IList<Survivor> GetAllSurvivor()
        {
            return _survivorRepository.GetAllSurvivor();
        }

        public IList<Survivor> GetAllUnInfectedSurvivor()
        {
            return _survivorRepository.GetAllInfectedSurvivor();
        }

        public IList<Survivor> GetPointLossFromInfectedSurvivor()
        {
            return _survivorRepository.GetAllUnInfectedSurvivor();
        }

        public IList<Survivor> GetResourceAverage()
        {
            return _survivorRepository.GetResourceAverage();
        }

        public Survivor GetSurvivorById(int survivorId)
        {
            return _survivorRepository.GetSurvivorById(survivorId);
        }

        public bool UpdateSurvivor(Survivor survivor)
        {
            return _survivorRepository.UpdateSurvivor(survivor);
        }
    }
}
