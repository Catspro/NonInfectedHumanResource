using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.TestHost;
using NonInfectedHumanResourceAPI;
using NonInfectedHumanResourceAPI.Business.Interfaces;
using NonInfectedHumanResourceAPI.Controllers;
using NonInfectedHumanResourceAPI.Entities;
using System;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using Xunit;

namespace NonInfectedHumanResource.Test
{
   
    public class UnitTest1
    {
        private readonly HttpClient _client;
        SurvivorController _controller;
        ISurvivorManager _survivorManager;

        public UnitTest1(ISurvivorManager survivorManager)
        {
            _survivorManager = survivorManager;
            _controller = new SurvivorController(_survivorManager);
            var server = new TestServer(new WebHostBuilder()
            .UseEnvironment("Development")
            .UseStartup<Startup>());
            _client = server.CreateClient();

        }
        [Fact]
        public void Test1()
        {

        }

        [Fact]
        public void GetAllTest()
        {
           

      
        //Arrange
        var incompleteBook = new Survivor() {
                SurvivorCode = "ZOMBIEXXXX",
            Gender = "Male",
            Age = 12,
            Location = 50.5,
            IsInfected = false,
            ReportedCount = 0,

        };

            //Act
            _controller.ModelState.AddModelError("Title", "Title is a requried filed");
            //var badResponse = _controller.Post(incompleteBook);

            //Assert
            //Assert.IsType<BadRequestObjectResult>(badResponse);

        }

        [Theory]
        [InlineData("GET")]
        public async Task GetAllSurvivors(string method)
        {

            //arrange
            var request = new HttpRequestMessage(new HttpMethod(method), "/GetAllSurvivors");

            //Act
            var response = await _client.SendAsync(request);

            //Assert
            response.EnsureSuccessStatusCode();
            Assert.Equal(HttpStatusCode.OK, response.StatusCode);

        }
    }
}
