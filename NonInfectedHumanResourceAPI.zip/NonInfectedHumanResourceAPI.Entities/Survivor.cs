﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NonInfectedHumanResourceAPI.Entities
{
    public class Survivor
    {

        public int Id { get; set; }

        public string SurvivorCode { get; set; }
        public string Gender { get; set; }
        public int Age { get; set; }

        public double Location { get; set; }

        public bool IsInfected { get; set; }

        public int ReportedCount { get; set; }

    }
}
