﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NonInfectedHumanResourceAPI.Entities;

namespace NonInfectedHumanResourceAPI.Repositories.Interfaces
{
    public interface ISurvivorRepository
    {
        bool AddSurvivor(Survivor survivor);
        bool UpdateSurvivor(Survivor survivor);
        bool DeleteSurvivor(int survivorId);

        IList<Survivor> GetAllSurvivor();


        IList<Survivor> GetAllInfectedSurvivor();


        IList<Survivor> GetAllUnInfectedSurvivor();


        IList<Survivor> GetResourceAverage();

        IList<Survivor> GetPointLossFromInfectedSurvivor();
        Survivor GetSurvivorById(int survivorId);
    }
}
