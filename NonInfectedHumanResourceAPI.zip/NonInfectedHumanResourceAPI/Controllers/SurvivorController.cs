﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using NonInfectedHumanResourceAPI.Business.Interfaces;
using NonInfectedHumanResourceAPI.Entities;
using NonInfectedHumanResourceAPI.Repositories.Interfaces;


namespace NonInfectedHumanResourceAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SurvivorController : ControllerBase
    {
        ISurvivorManager _survivorManager;

        public SurvivorController(ISurvivorManager survivorManager)
        {
            _survivorManager = survivorManager;
        }

        // GET: api/survivor
       
        [HttpPost("~/GetAllSurvivors")]
        public IEnumerable<Survivor> Get()
        {
            return _survivorManager.GetAllSurvivor();
        }

        // GET api/survivor/5
        [HttpGet("{id}")]
        public Survivor Get(int id)
        {
            return _survivorManager.GetSurvivorById(id);
        }

        // POST api/survivor
     
        [HttpPost("~/AddSurvivors")]
        public void Post([FromBody] Survivor survivor)
        {
            _survivorManager.AddSurvivor(survivor);
        }

        // PUT api/survivor/5
        //[HttpPut("{id}")]
        [HttpPut("~/UpdateSurvivors/{id}")]
        public void Put(int id, [FromBody] Survivor survivor)
        {
            _survivorManager.UpdateSurvivor(survivor);
        }

        // DELETE api/survivor/5
       // [HttpDelete("{id}")]
      
        //public void Delete(int id)
        //{
           // _survivorManager.DeleteSurvivor(id);
        //}
    }
}
