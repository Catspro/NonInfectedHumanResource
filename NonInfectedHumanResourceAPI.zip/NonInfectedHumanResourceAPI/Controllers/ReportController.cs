﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using NonInfectedHumanResourceAPI.Business.Interfaces;
using NonInfectedHumanResourceAPI.Entities;
using NonInfectedHumanResourceAPI.Repositories.Interfaces;
namespace NonInfectedHumanResourceAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ReportController : ControllerBase
    {
        ISurvivorManager _survivorManager;

        public ReportController(ISurvivorManager survivorManager)
        {
            _survivorManager = survivorManager;
        }

        // GET: api/user
        [HttpGet]
        [HttpGet("~/getinfectedPercentage")]
        public IEnumerable<Survivor> GetInfectedPercentage()
        {
            return _survivorManager.GetAllInfectedSurvivor();
        }

        [HttpGet]
        [HttpGet("~/getuninfectedPercentage")]
        public IEnumerable<Survivor> GetUnInfectedPercentageReport()
        {
            return _survivorManager.GetAllUnInfectedSurvivor();
        }

        [HttpGet]
        [HttpGet("~/getaverageamountofResource")]
        public IEnumerable<Survivor> GetAverageAmountOfResource()
        {
            return _survivorManager.GetResourceAverage();
        }

        [HttpGet]
        [HttpGet("~/getpointlossfromInfectedSurvivor")]
        public IEnumerable<Survivor> PointLossfromInfectedSurvivor()
        {
            return _survivorManager.GetPointLossFromInfectedSurvivor();
        }






    }
}